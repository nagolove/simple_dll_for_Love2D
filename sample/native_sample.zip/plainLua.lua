
print("package.cpath", package.cpath)
package.cpath = package.cpath .. ";?.dll"
print("package.cpath", package.cpath)

lib=require("lovelib")

print(lib.doubles(1234))
-- 2468
-- output the double value of the input

print(lib.avr(113,446,779))
-- 446	1338
-- output the average and the sum of the input array
